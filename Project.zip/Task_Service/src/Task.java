public class Task {
    private final String taskId; // ID can't be changed
    private String name;
    private String description;

    public Task(String taskId, String name, String description) {
        this.taskId = sanitizeTaskId(taskId);
        this.name = sanitizeName(name);
        this.description = sanitizeDescription(description);
    }

    private String sanitizeTaskId(String id) {
        if (id.isEmpty() || id.length() > 10) {
            return "No idID";
        }
        return id;
    }

    private String sanitizeName(String name) {
        if (name.isEmpty() || name.length() > 20) {
            return "No name";
        }
        return name;
    }

    private String sanitizeDescription(String description) {
        if (description.isEmpty() || description.length() > 50) {
            return "No description";
        }
        return description;
    }

    public String getTaskId() {
        return taskId;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public void setName(String name) {
        this.name = sanitizeName(name);
    }

    public void setDescription(String description) {
        this.description = sanitizeDescription(description);
    }
}
