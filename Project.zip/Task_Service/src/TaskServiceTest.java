import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;
import static org.junit.jupiter.api.Assertions.*;

public class TaskServiceTest {
    private TaskService service;
    private Task task1;

    @BeforeEach
    public void setUp() {
        service = new TaskService();
        task1 = new Task("T1", "Task One", "Description One");
    }

    @Test
    public void testAddTask() {
        assertTrue(service.addTask(task1));
        assertFalse(service.addTask(task1)); // duplicate
    }

    @Test
    public void testDeleteTask() {
        service.addTask(task1);
        assertTrue(service.deleteTask("T1"));
        assertFalse(service.deleteTask("T1")); // already deleted
    }

    @Test
    public void testUpdateName() {
        service.addTask(task1);
        assertTrue(service.updateName("T1", "Updated Name"));
        assertEquals("Updated Name", service.getTaskOrDefault("T1").getName());
    }

    @Test
    public void testUpdateDescription() {
        service.addTask(task1);
        assertTrue(service.updateDescription("T1", "Updated Description"));
        assertEquals("Updated Description", service.getTaskOrDefault("T1").getDescription());
    }

    @Test
    public void testUpdateInvalidTask() {
        assertFalse(service.updateName("999", "Doesn't Exist"));
        assertFalse(service.updateDescription("999", "No Desc"));
    }

    @Test
    public void testGetFallbackTask() {
        Task fallback = service.getTaskOrDefault("NotThere");
        assertEquals("No ID", fallback.getTaskId());
        assertEquals("No name", fallback.getName());
    }

    @Test
    public void testGetAllTasks() {
        service.addTask(task1);
        assertEquals(1, service.getAllTasks().size());
    }

    // Updated

    @Test
    public void testTaskIdTooLong() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345678901", "Valid Name", "Valid Description"); // 11 characters
        });
    }

    @Test
    public void testNameTooLong() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Task("123", "This name too long", "Valid Description");
        });
    }

    @Test
    public void testDescriptionTooLong() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Task("123", "Valid Name", "This is a test task with long description");
        });
    }

    @Test
    public void testValidTaskMaxLengths() {
        String id = "1234567890"; // 10 chars
        String name = "12345678901234567890"; // 20 chars
        String description = "123456789012345678901234567890"; // 30 chars
        Task validTask = new Task(id, name, description);
        assertEquals(id, validTask.getTaskId());
        assertEquals(name, validTask.getName());
        assertEquals(description, validTask.getDescription());
    }
}

