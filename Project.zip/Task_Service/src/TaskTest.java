import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TaskTest {

    @Test
    public void testValidTaskCreation() {
        Task task = new Task("123", "Test Task", "Task description.");
        assertEquals("123", task.getTaskId());
        assertEquals("Test Task", task.getName());
        assertEquals("Task description.", task.getDescription());
    }

    @Test
    public void testInvalidTaskId() {
        Task task = new Task("", "Test", "Desc");
        assertEquals("no ID", task.getTaskId());
    }

    @Test
    public void testInvalidName() {
        Task task = new Task("001", "", "Desc");
        assertEquals("No name", task.getName());
    }

    @Test
    public void testInvalidDescription() {
        Task task = new Task("002", "Test", "");
        assertEquals("No description", task.getDescription());
    }

    @Test
    public void testSetName() {
        Task task = new Task("003", "Old", "Desc");
        task.setName("New Name");
        assertEquals("New Name", task.getName());
    }

    @Test
    public void testSetInvalidName() {
        Task task = new Task("004", "Old", "Desc");
        task.setName(""); // invalid
        assertEquals("No name", task.getName());
    }

    @Test
    public void testSetDescription() {
        Task task = new Task("005", "Name", "Old Description");
        task.setDescription("New description");
        assertEquals("New description", task.getDescription());
    }

    @Test
    public void testSetInvalidDescription() {
        Task task = new Task("006", "Name", "Old Description");
        task.setDescription(""); // invalid
        assertEquals("No description", task.getDescription());
    }
}
