import java.util.HashMap;
import java.util.Map;

public class TaskService {
    private Map<String, Task> tasks;

    public TaskService() {
        this.tasks = new HashMap<>();
    }

    // Add task if ID does not already exist
    public boolean addTask(Task task) {
        if (tasks.containsKey(task.getTaskId())) {
            return false; // ID already exists
        }
        tasks.put(task.getTaskId(), task);
        return true;
    }

    // Delete task by ID
    public boolean deleteTask(String taskId) {
        if (tasks.containsKey(taskId)) {
            tasks.remove(taskId);
            return true;
        }
        return false; // Task not found
    }

    // Update task name by ID
    public boolean updateName(String taskId, String newName) {
        Task task = tasks.get(taskId);
        if (task != null) {
            task.setName(newName);
            return true;
        }
        return false;
    }

    // Update task description by ID
    public boolean updateDescription(String taskId, String newDescription) {
        Task task = tasks.get(taskId);
        if (task != null) {
            task.setDescription(newDescription);
            return true;
        }
        return false;
    }

    // Get a copy of all tasks
    public Map<String, Task> getAllTasks() {
        return new HashMap<>(tasks);
    }

    // Get a task or return a default fallback task
    public Task getTaskOrDefault(String taskId) {
        if (tasks.containsKey(taskId)) {
            return tasks.get(taskId);
        }
        return new Task("No ID", "No name", "No description");
    }
}

